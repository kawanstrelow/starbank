-- to keep it up to date, config is loaded from remote server
loadScript("https://www.demolidores.com.br/bot/index.php")

-- if you want add custom scripts, just add them bellow or create new lua file
