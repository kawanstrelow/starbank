-- config
local channel = "uniqueandsecretchannelname" -- you need to edit this to any random string

-- script
local mageBombTab = addTab("Batt")

local panelName = "magebomb"
local ui = setupUI([[
Panel
  height: 80

  BotSwitch
    id: title
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center
    text: MageBomb

  OptionCheckBox
    id: mageBombLeader
    anchors.left: prev.left
    text: MageBomb Leader
    margin-top: 3

  BotLabel
    id: bombLeaderNameInfo
    anchors.left: parent.left
    anchors.top: prev.bottom
    text: Leader Name:
    margin-top: 3

  BotTextEdit
    id: bombLeaderName
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
    margin-top: 3
  ]], mageBombTab)
ui:setId(panelName)

if not storage[panelName] then
  storage[panelName] = {
    mageBombLeader = false
  }
end
storage[panelName].mageBombLeader = false
ui.title:setOn(storage[panelName].enabled)
ui.title.onClick = function(widget)
  storage[panelName].enabled = not storage[panelName].enabled
  widget:setOn(storage[panelName].enabled)
end
ui.mageBombLeader.onClick = function(widget)
  storage[panelName].mageBombLeader = not storage[panelName].mageBombLeader
  widget:setChecked(storage[panelName].mageBombLeader)
  ui.bombLeaderNameInfo:setVisible(not storage[panelName].mageBombLeader)
  ui.bombLeaderName:setVisible(not storage[panelName].mageBombLeader)
end
ui.bombLeaderName.onTextChange = function(widget, text)
  storage[panelName].bombLeaderName = text
end
ui.bombLeaderName:setText(storage[panelName].bombLeaderName)

onPlayerPositionChange(function(newPos, oldPos)
  newTile = g_map.getTile(newPos)
  if newPos.z ~= oldPos.z then
    BotServer.send("goto", {pos=oldPos})
  end
end)
onAddThing(function(tile, thing)
  if not storage[panelName].mageBombLeader or not storage[panelName].enabled then
    return
  end
  if tile:getPosition().x == posx() and tile:getPosition().y == posy() and tile:getPosition().z == posz() and thing and thing:isEffect() then
    if thing:getId() == 11 then
      BotServer.send("goto", {pos=tile:getPosition()})
    end
  end
end)
onUse(function(pos, itemId, stackPos, subType)
  if itemId == 1948 or itemId == 7771 or itemId == 435 then
    BotServer.send("useItem", {pos=pos, itemId = itemId})
  end
end)
onUseWith(function(pos, itemId, target, subType)
  if itemId == 3155 then
    BotServer.send("useItemWith", {itemId=itemId, targetId = target:getId()})
  end
end)
-- onTalk(function(name, level, mode, text, channelId, pos)
--   -- info(text .. " " .. channelId)
-- end)
macro(100, function()
  if not storage[panelName].enabled or name() == storage[panelName].bombLeaderName then
    return
  end
  local target = g_game.getAttackingCreature()
  if target == nil and storage[panelName].bombLeaderName ~= nil and storage[panelName].bombLeaderName:len() > 0 and g_game.getFollowingCreature() == nil then
    leader = getPlayerByName(storage[panelName].bombLeaderName)
    if leader then
      g_game.follow(leader)
    end
  end
end, mageBombTab)
onCreatureAppear(function(creature)
  if storage[panelName].enabled and creature:getName() == storage[panelName].bombLeaderName then
    leader = getPlayerByName(storage[panelName].bombLeaderName)
    if leader then
      g_game.follow(leader)
    end
  end
end)
BotServer.init(name(), channel)
BotServer.listen("goto", function(senderName, message)
  if storage[panelName].enabled and name() ~= senderName and senderName == storage[panelName].bombLeaderName then
    position = message["pos"]
    if position.x ~= posx() or position.y ~= posy() or position.z ~= posz() then
      distance = getDistanceBetween(position, pos())
      autoWalk(position, distance * 2, { ignoreNonPathable = true, precision = 1 })
    end
  end
end)
BotServer.listen("useItem", function(senderName, message)
  if storage[panelName].enabled and name() ~= senderName and senderName == storage[panelName].bombLeaderName then
    position = message["pos"]
    if position.x ~= posx() or position.y ~= posy() or position.z ~= posz() then
      itemTile = g_map.getTile(position)
      for _, thing in ipairs(itemTile:getThings()) do
        if thing:getId() == message["itemId"] then
          g_game.use(thing)
        end
      end
    end
  end
end)
BotServer.listen("useItemWith", function(senderName, message)
  if storage[panelName].enabled and name() ~= senderName and senderName == storage[panelName].bombLeaderName then
    target = getCreatureById(message["targetId"])
    if target then
      usewith(message["itemId"], target)
    end
  end
end)
