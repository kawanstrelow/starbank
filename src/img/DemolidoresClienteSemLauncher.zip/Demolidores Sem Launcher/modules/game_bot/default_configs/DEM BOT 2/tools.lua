local toolsTab = addTab("Tools")

function autoExiva(parent)
  if not parent then
    parent = panel
  end

  panelName = "autoExiva"
  local ui = setupUI([[
Panel
  height: 80
  margin-top: 2

  BotSwitch
    id: title
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center
    text: Auto exiva every 500

  BotTextEdit
    id: spellWords
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
    margin-top: 3

  BotTextEdit
    id: playerName
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
    margin-top: 3

  HorizontalScrollBar
    id: timeout
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
    margin-right: 2
    margin-top: 3
    minimum: 1
    maximum: 200
    step: 1
  ]], parent)
  ui:setId(panelName)
  if not storage[panelName] then
    storage[panelName] = {
      spellWords = "exiva",
      playerName = "",
      timeout = 5
    }
  end

  ui.title.onClick = function(widget)
    storage[panelName].enabled = not storage[panelName].enabled
    widget:setOn(storage[panelName].enabled)
  end
  ui.spellWords.onTextChange = function(widget, text)
    storage[panelName].spellWords = text
  end
  ui.playerName.onTextChange = function(widget, text)
    storage[panelName].playerName = text
  end
  local updateText = function()
    ui.title:setText("Exiva every " .. storage[panelName].timeout .. " seconds")  
  end
  ui.timeout.onValueChange = function(scroll, value)
    storage[panelName].timeout = value
    updateText()
  end
  ui.spellWords:setText(storage[panelName].spellWords)
  ui.playerName:setText(storage[panelName].playerName)
  ui.timeout:setValue(storage[panelName].timeout)

  onTalk(function(pname, level, mode, text, channelId, pos)
    if pname == name() and string.match(text, "exiva") then
      playerName = string.match(text, '"(.+)"')
      if playerName:len() > 0 then
        storage[panelName].playerName = playerName
        ui.playerName:setText(storage[panelName].playerName)
      end
    end
  end)

  macro(100, function()
    if storage[panelName].enabled and storage[panelName].spellWords:len() > 0 and storage[panelName].playerName:len() > 0 then
      saySpell(storage[panelName].spellWords .. ' "' .. storage[panelName].playerName)
      delay(storage[panelName].timeout * 1000)
    end
  end)
end
autoExiva(toolsTab)
macro(1000, "exchange money", function()
  local containers = getContainers()
  for i, container in pairs(containers) do
    for j, item in ipairs(container:getItems()) do
      if item:isStackable() and (item:getId() == 3035 or item:getId() == 3031 or item:getId() == 3043) and item:getCount() == 100 then
        g_game.use(item)
        return
      end
    end
  end
end)

function superDash(parent)
 if not parent then
    parent = panel
  end
  local switch = g_ui.createWidget('BotSwitch', parent)
  switch:setId("superDashButton")
  switch:setText("Super Dash")
  switch:setOn(storage.superDash)
  switch.onClick = function(widget)    
    storage.superDash = not storage.superDash
    widget:setOn(storage.superDash)
  end

  onKeyPress(function(keys)
    if not storage.superDash then
      return
    end
    consoleModule = modules.game_console
    if (keys == "W" and not consoleModule:isChatEnabled()) or keys == "Up" then
      moveToTile = g_map.getTile({x = posx(), y = posy()-1, z = posz()})
      if moveToTile and not moveToTile:isWalkable(false) then
        moveToPos = {x = posx(), y = posy()-6, z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
      end
    elseif (keys == "A" and not consoleModule:isChatEnabled()) or keys == "Left" then
      moveToTile = g_map.getTile({x = posx()-1, y = posy(), z = posz()})
      if moveToTile and not moveToTile:isWalkable(false) then
        moveToPos = {x = posx()-6, y = posy(), z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
      end
    elseif (keys == "S" and not consoleModule:isChatEnabled()) or keys == "Down" then
      moveToTile = g_map.getTile({x = posx(), y = posy()+1, z = posz()})
      if moveToTile and not moveToTile:isWalkable(false) then
        moveToPos = {x = posx(), y = posy()+6, z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
      end
    elseif (keys == "D" and not consoleModule:isChatEnabled()) or keys == "Right" then
      moveToTile = g_map.getTile({x = posx()+1, y = posy(), z = posz()})
      if moveToTile and not moveToTile:isWalkable(false) then
        moveToPos = {x = posx()+6, y = posy(), z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
      end
    end
  end)
end
superDash()

macro(100, "debug pathfinding", nil, function()
  for i, tile in ipairs(g_map.getTiles(posz())) do
    tile:setText("")
  end
  local path = findEveryPath(pos(), 20, {
    ignoreNonPathable = false
  })
  local total = 0
  for i, p in pairs(path) do
    local s = i:split(",")
    local pos = {x=tonumber(s[1]), y=tonumber(s[2]), z=tonumber(s[3])}
    local tile = g_map.getTile(pos)
    if tile then
      tile:setText(p[2])
    end
     total = total + 1
  end
end)



local positionLabel = addLabel("positionLabel", "")
onPlayerPositionChange(function()
  positionLabel:setText("Pos: " .. posx() .. "," .. posy() .. "," .. posz())
end)

local s = addSwitch("sdSound", "Play sound when using sd", function(widget)
  storage.sdSound = not storage.sdSound
  widget:setOn(storage.sdSound)
end)
s:setOn(storage.sdSound)

onUseWith(function(pos, itemId)
  if storage.sdSound and itemId == 3155 then
    playSound("/sounds/magnum.ogg")
  end
end)




