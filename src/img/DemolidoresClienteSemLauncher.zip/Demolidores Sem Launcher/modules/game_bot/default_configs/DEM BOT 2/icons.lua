local toolsTab = addTab("Tools")

function AddScrolls(panelName, parent)
  if not parent then
    parent = panel
  end
 
  local ui = setupUI([[
Panel
  height: 50
  margin-top: 2

  BotItem
    id: bpId
    anchors.left: parent.left
    anchors.top: parent.top

  BotLabel
    id: title
    anchors.left: bpId.right
    anchors.right: parent.right
    anchors.top: bpId.verticalCenter
    text-align: center

  HorizontalScrollBar
    id: scroll1
    anchors.left: parent.left
    anchors.right: parent.horizontalCenter
    anchors.top: bpId.bottom
    margin-right: 2
    margin-top: 2
    minimum: 0
    maximum: 100
    step: 1
    
  HorizontalScrollBar
    id: scroll2
    anchors.left: parent.horizontalCenter
    anchors.right: parent.right
    anchors.top: prev.top
    margin-left: 2
    minimum: 0
    maximum: 100
    step: 1    
  ]], parent)
  ui:setId(panelName)
  if not storage[panelName] or not storage[panelName].bpId then
    storage[panelName] = {
      min = 60,
      max = 90,
      bpId = 2854
    }
  end
  
  local updateText = function()
    ui.title:setText("" .. storage[panelName].min .. "% <= hp >= " .. storage[panelName].max .. "%")  
  end
 
  ui.scroll1.onValueChange = function(scroll, value)
    storage[panelName].min = value
    updateText()
  end
  ui.scroll2.onValueChange = function(scroll, value)
    storage[panelName].max = value
    updateText()
  end
  ui.bpId.onItemChange = function(widget)
    storage[panelName].bpId = widget:getItemId()
  end
 
  ui.scroll1:setValue(storage[panelName].min)
  ui.scroll2:setValue(storage[panelName].max)
  ui.bpId:setItemId(storage[panelName].bpId)
end

local defaultAmulet = nil
macro(100, "Equip SSA", function()
  if hppercent() <= storage["ssa"].min and (getNeck() == nil or getNeck():getId() ~= 3081) then
    if getNeck() ~= nil and defaultAmulet == nil then
      defaultAmulet = getNeck():getId()
    end
    for _, container in pairs(getContainers()) do
      for _, item in ipairs(container:getItems()) do
        containerItem = container:getContainerItem():getId()
        if containerItem == storage["ssa"].bpId then
          if item:getId() == 3081 then
            if container:getSize() == 0 and getNeck() ~= nil  then
              g_game.moveToParentContainer(item, item:getCount())
              delay(300)
              return
            end
            moveToSlot(item, SlotNeck)
            delay(200)
            return
          end
        end
      end
    end
    if defaultAmulet ~= nil or (getNeck() ~= nil and getNeck():getId() ~= defaultAmulet) then
      amulet = findItem(defaultAmulet)
      if amulet then
        moveToSlot(amulet, SlotNeck)
      end
    end
    isAlreadyOpen = false
    for i, container in pairs(getContainers()) do
      containerItem = container:getContainerItem():getId()
      if containerItem == storage["ssa"].bpId then
        isAlreadyOpen = true
        for _, item in ipairs(container:getItems()) do
          if item:isContainer() and item:getId() == storage["ssa"].bpId then
            g_game.open(item, container)
            delay(200)
            return
          end
        end
      end
    end
    if not isAlreadyOpen then
      for i, container in pairs(getContainers()) do
        for _, item in ipairs(container:getItems()) do
          if item:isContainer() and item:getId() == storage["ssa"].bpId then
            g_game.open(item)
            delay(400)
            return
          end
        end
      end
    end
  elseif hppercent() >= storage["ssa"].max and defaultAmulet ~= nil then
    if getNeck() == nil or (getNeck() ~= nil and getNeck():getId() ~= defaultAmulet) then
      amulet = findItem(defaultAmulet)
      if amulet then
        moveToSlot(amulet, SlotNeck)
      end
    end
  end
end, toolsTab)
AddScrolls("ssa", toolsTab)
addSeparator("sep", toolsTab)

local defaultRing = nil
macro(100, "Equip E-Ring", function()
  if hppercent() <= storage["ering"].min and (getFinger() == nil or (getFinger():getId() ~= 3051 and getFinger():getId() ~= 3088)) then
    if getFinger() ~= nil and defaultRing == nil then
      defaultRing = getFinger()
    end
    ring = findItem(3051)
    findRing = false
    if ring then
      moveToSlot(ring, SlotFinger)
      delay(20)
    end

    if ring == nil then
      if defaultRing ~= nil or (getFinger() ~= nil and getFinger():getId() ~= defaultRing:getId()) then
        ring = findItem(defaultRing:getId())
        if ring then
          moveToSlot(ring, SlotFinger)
        end
      end
      findRing = true
    end

    if findRing then
      isAlreadyOpen = false
      for i, container in pairs(getContainers()) do
        containerItem = container:getContainerItem():getId()
        if containerItem == storage["ering"].bpId then
          isAlreadyOpen = true
          for _, item in ipairs(container:getItems()) do
            if item:isContainer() and item:getId() == storage["ering"].bpId then
              g_game.open(item, container)
              delay(30)
              return
            end
          end
        end
      end
      if not isAlreadyOpen then
        for i, container in pairs(getContainers()) do
          for _, item in ipairs(container:getItems()) do
            if item:isContainer() and item:getId() == storage["ering"].bpId then
              g_game.open(item)
              delay(40)
              return
            end
          end
        end
      end
    end
  elseif hppercent() >= storage["ering"].max and defaultRing ~= nil then
    if getFinger() == nil or (getFinger():getId() ~= defaultRing:getId()) then
      ring = findItem(defaultRing:getId())
      if ring then
        moveToSlot(ring, SlotFinger)
      end
    end
  end
end, toolsTab)
AddScrolls("ering", toolsTab)
addSeparator("sep", toolsTab)

function conjuringScript(parent)
  local panelName = "conjureScript"
 
  local ui = setupUI([[
Panel
  height: 60
  margin-top: 2

  SmallBotSwitch
    id: title
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center

  HorizontalScrollBar
    id: scroll1
    anchors.left: title.left
    anchors.right: title.right
    anchors.top: title.bottom
    margin-right: 2
    margin-top: 2
    minimum: 0
    maximum: 100
    step: 1

  BotTextEdit
    id: text
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: scroll1.bottom
    margin-top: 3 
  
  ]], parent)
  ui:setId(panelName)
 
  if not storage[panelName] then
    storage[panelName] = {
      min = 5,
      text = "adori dodge"
    }
  end
 
  ui.title:setOn(storage[panelName].enabled)
  ui.title.onClick = function(widget)
    storage[panelName].enabled = not storage[panelName].enabled
    widget:setOn(storage[panelName].enabled)
  end
 
  ui.text.onTextChange = function(widget, text)
    storage[panelName].text = text
  end
  ui.text:setText(storage[panelName].text or "adori dodge")
 
  local updateText = function()
    ui.title:setText("Conjure Spell Soul > " .. storage[panelName].min)  
  end
 
  ui.scroll1.onValueChange = function(scroll, value)
    storage[panelName].min = value
    updateText()
  end
 
  ui.scroll1:setValue(storage[panelName].min)
 
  macro(25, function()
    if storage[panelName].enabled and storage[panelName].text:len() > 0 and soul() >= storage[panelName].min then
      if saySpell(storage[panelName].text, 500) then
        delay(200)
      end
    end
  end)
end
conjuringScript(toolsTab)
addSeparator("sep", toolsTab)

function comboScript(parent)
  if not parent then
    parent = panel
  end
 
  local panelName = "comboScriptPanel"
 
  local ui = setupUI([[
ThreeRowsItems < Panel
  height: 99
  margin-top: 2
  
  BotItem
    id: item1
    anchors.top: parent.top
    anchors.left: parent.left

  BotItem
    id: item2
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2

  BotItem
    id: item3
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2

  BotItem
    id: item4
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2

  BotItem
    id: item5
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item6
    anchors.top: prev.bottom
    anchors.left: parent.left
    margin-top: 2

  BotItem
    id: item7
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item8
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item9
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item10
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item11
    anchors.top: prev.bottom
    anchors.left: parent.left
    margin-top: 2
    
  BotItem
    id: item12
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item13
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item14
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2
    
  BotItem
    id: item15
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 2

Panel
  height: 135

  SmallBotSwitch
    id: title
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center

  HorizontalScrollBar
    id: scroll1
    anchors.left: title.left
    anchors.right: title.right
    anchors.top: title.bottom
    margin-right: 2
    margin-top: 2
    minimum: 1
    maximum: 60
    step: 1

  ThreeRowsItems
    id: items
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom  
  ]], parent)
  ui:setId(panelName)
 
  if not storage[panelName] then
    storage[panelName] = {
      time = 31
    }
  end
 
  local updateText = function()
    ui.title:setText("Use every " .. storage[panelName].time .. " minutes")  
  end
 
  ui.scroll1.onValueChange = function(scroll, value)
    storage[panelName].time = value
    updateText()
  end
 
  ui.scroll1:setValue(storage[panelName].time)
 
  ui.title:setOn(storage[panelName].enabled)
  ui.title.onClick = function(widget)
    storage[panelName].enabled = not storage[panelName].enabled
    widget:setOn(storage[panelName].enabled)
  end
 
  if type(storage[panelName].items) ~= 'table' then
    storage[panelName].items = { 3215, 9642, 3726, 11454, 945, 10293, 10306, 10316, 11455 }
  end
 
  for i=1,15 do
    ui.items:getChildByIndex(i).onItemChange = function(widget)
      storage[panelName].items[i] = widget:getItemId()
    end
    ui.items:getChildByIndex(i):setItemId(storage[panelName].items[i])    
  end
 
  macro(1000, function()
    if not storage[panelName].enabled then
      return
    end
    storage.cavebot.enabled = false
    storage.attacking.enabled = false
    if #storage[panelName].items > 0 then
      timeOut = 5000
      for _, itemToUse in pairs(storage[panelName].items) do
        schedule(timeOut, function()
          use(itemToUse)
        end)
        timeOut = timeOut + 500
      end
    end
    schedule(timeOut + 5000, function()
      storage.cavebot.enabled = true
      storage.attacking.enabled = true
    end)
    delay((storage[panelName].time * 60000) - 1000)
  end)
end
comboScript(toolsTab)
addSeparator("sep", toolsTab)

function staminaItems(parent)
  if not parent then
    parent = panel
  end
  local panelName = "staminaItemsUser"
  local ui = setupUI([[
Panel
  height: 65
  margin-top: 2

  SmallBotSwitch
    id: title
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center

  HorizontalScrollBar
    id: scroll1
    anchors.left: parent.left
    anchors.right: parent.horizontalCenter
    anchors.top: title.bottom
    margin-right: 2
    margin-top: 2
    minimum: 0
    maximum: 42
    step: 1
    
  HorizontalScrollBar
    id: scroll2
    anchors.left: parent.horizontalCenter
    anchors.right: parent.right
    anchors.top: prev.top
    margin-left: 2
    minimum: 0
    maximum: 42
    step: 1    

  ItemsRow
    id: items
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
  ]], parent)
  ui:setId(panelName)

  if not storage[panelName] then
    storage[panelName] = {
      min = 25,
      max = 40,
    }
  end

  local updateText = function()
    ui.title:setText("" .. storage[panelName].min .. " <= stamina >= " .. storage[panelName].max .. "")  
  end
 
  ui.scroll1.onValueChange = function(scroll, value)
    storage[panelName].min = value
    updateText()
  end
  ui.scroll2.onValueChange = function(scroll, value)
    storage[panelName].max = value
    updateText()
  end
 
  ui.scroll1:setValue(storage[panelName].min)
  ui.scroll2:setValue(storage[panelName].max)
 
  ui.title:setOn(storage[panelName].enabled)
  ui.title.onClick = function(widget)
    storage[panelName].enabled = not storage[panelName].enabled
    widget:setOn(storage[panelName].enabled)
  end
 
  if type(storage[panelName].items) ~= 'table' then
    storage[panelName].items = { 11588 }
  end
 
  for i=1,5 do
    ui.items:getChildByIndex(i).onItemChange = function(widget)
      storage[panelName].items[i] = widget:getItemId()
    end
    ui.items:getChildByIndex(i):setItemId(storage[panelName].items[i])    
  end
 
  macro(500, function()
    if not storage[panelName].enabled or stamina() / 60 < storage[panelName].min or stamina() / 60 > storage[panelName].max then
      return
    end
    local candidates = {}
    for i, item in pairs(storage[panelName].items) do
      if item >= 100 then
        table.insert(candidates, item)
      end
    end
    if #candidates == 0 then
      return
    end    
    use(candidates[math.random(1, #candidates)])
  end)
end
staminaItems(toolsTab)
addSeparator("sep", toolsTab)

-- open Backpacks when reconnect
containers = getContainers()
if #containers < 1 and containers[0] == nil then
  bpItem = getBack()
  if bpItem ~= nil then
    g_game.open(bpItem)
  end
  say("!bless")
end

macro(10000, "Anti Idle",  function()
  local oldDir = direction()
  turn((oldDir + 1) % 4)
  schedule(1000, function() -- Schedule a function after 1000 milliseconds.
    turn(oldDir)
  end)
end)





