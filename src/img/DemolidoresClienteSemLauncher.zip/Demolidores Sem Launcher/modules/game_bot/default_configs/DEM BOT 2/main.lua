Panels.TradeMessage()
Panels.AutoStackItems()

addButton("discord", "Discord & Help", function()
  g_platform.openUrl("https://discord.me/Demolidores")
end)

addButton("forum", "Forum", function()
  g_platform.openUrl("https://www.demolidores.com.br/?subtopic=forum")
end)

addSeparator("sep")
local oldTarget
macro(200, "hold target",  function()
    if g_game.isAttacking() then
        oldTarget = g_game.getAttackingCreature()
    end
    if (oldTarget and not g_game.isAttacking() and getDistanceBetween(pos(), oldTarget:getPosition()) <= 8) then
        g_game.attack(oldTarget)
    end
end)
function clickReuse(parent)
  if not parent then
    parent = panel
  end
  local ui = setupUI([[
Panel
  height: 20
  margin-top: 2

  BotSwitch
    id: title
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center
    text: Click Reuse
    ]], parent)
  ui:setId("clickReuse")

  ui.title:setOn(storage.clickReuse)
  ui.title.onClick = function(widget)
    storage.clickReuse = not storage.clickReuse
    widget:setOn(storage.clickReuse)
  end
  onUseWith(function(pos, itemId, target, subType)
    if storage.clickReuse then
      schedule(50, function()
        item = findItem(itemId)
        if item then
          modules.game_interface.startUseWith(item)
        end
      end)
    end
  end)
end
clickReuse()
