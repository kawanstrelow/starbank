local batTab = addTab("Batt")

Panels.AttackSpell(batTab)
addSeparator("sep", batTab)
Panels.AttackItem(batTab)
addSeparator("sep", batTab)
Panels.AttackLeaderTarget(batTab)
addSeparator("sep", batTab)
Panels.LimitFloor(batTab)
addSeparator("sep", batTab)
Panels.AntiPush(batTab)
addSeparator("sep", batTab)
function friendHealer(parent)
  local panelName = "advancedFriendHealer"
  local ui = setupUI([[
Panel
  height: 135
  margin-top: 2

  BotSwitch
    id: title
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center
    text: Friend Healer

  BotTextEdit
    id: spellName
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: title.bottom
    margin-top: 3

  BotButton
    id: editList
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
    text-align: center
    text: Edit List
    margin-top: 3

  SmallBotSwitch
    id: partyAndGuildMembers
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
    text-align: center
    text: Heal Party/Guild
    margin-top: 3

  BotLabel
    id: manaInfo
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: partyAndGuildMembers.bottom
    text-align: center

  HorizontalScrollBar
    id: minMana
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: manaInfo.bottom
    margin-top: 2
    minimum: 1
    maximum: 100
    step: 1

  BotLabel
    id: friendHp
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: prev.bottom
    text-align: center

  HorizontalScrollBar
    id: minFriendHp
    anchors.left: parent.left
    anchors.right: parent.horizontalCenter
    anchors.top: friendHp.bottom
    margin-right: 2
    margin-top: 2
    minimum: 1
    maximum: 100
    step: 1
    
  HorizontalScrollBar
    id: maxFriendHp
    anchors.left: parent.horizontalCenter
    anchors.right: parent.right
    anchors.top: prev.top
    margin-left: 2
    minimum: 1
    maximum: 100
    step: 1    
  ]], parent)
  ui:setId(panelName)

  if not storage[panelName] then
    storage[panelName] = {
      minMana = 60,
      minFriendHp = 40,
      maxFriendHp = 90,
      spellName = "exura sio",
      sioList = {},
      partyAndGuildMembers = true
    }
  end


  rootWidget = g_ui.getRootWidget()
  sioListWindow = g_ui.createWidget('SioListWindow', rootWidget)
  sioListWindow:hide()

  if storage[panelName].sioList and #storage[panelName].sioList > 0 then
    for _, sioName in ipairs(storage[panelName].sioList) do
      local label = g_ui.createWidget("SioFriendName", sioListWindow.SioList)
      label.remove.onClick = function(widget)
        table.removevalue(storage[panelName].sioList, label:getText())
        label:destroy()
      end
      label:setText(sioName)
    end
  end

  sioListWindow.close.onClick = function(widget)
    sioListWindow:hide()
  end

  sioListWindow.AddFriend.onClick = function(widget)
    local friendName = sioListWindow.FriendName:getText()
    if friendName:len() > 0 and not table.contains(storage[panelName].sioList, friendName, true) then
      table.insert(storage[panelName].sioList, friendName)
      local label = g_ui.createWidget("SioFriendName", sioListWindow.SioList)
      label.remove.onClick = function(widget)
        table.removevalue(storage[panelName].sioList, label:getText())
        label:destroy()
      end
      label:setText(friendName)
      sioListWindow.FriendName:setText('')
    end
  end

  ui.title:setOn(storage[panelName].enabled)
  ui.partyAndGuildMembers:setOn(storage[panelName].partyAndGuildMembers)

  ui.title.onClick = function(widget)
    storage[panelName].enabled = not storage[panelName].enabled
    widget:setOn(storage[panelName].enabled)
  end

  ui.partyAndGuildMembers.onClick = function(widget)
    storage[panelName].partyAndGuildMembers = not storage[panelName].partyAndGuildMembers
    widget:setOn(storage[panelName].partyAndGuildMembers)
  end
  ui.editList.onClick = function(widget)
    sioListWindow:show()
    sioListWindow:raise()
    sioListWindow:focus()
  end
  ui.spellName.onTextChange = function(widget, text)
    storage[panelName].spellName = text
  end
  local updateMinManaText = function()
    ui.manaInfo:setText("Minimum Mana >= " .. storage[panelName].minMana)
  end
  local updateFriendHpText = function()
    ui.friendHp:setText("" .. storage[panelName].minFriendHp .. "% <= hp >= " .. storage[panelName].maxFriendHp .. "%")  
  end

  ui.minMana.onValueChange = function(scroll, value)
    storage[panelName].minMana = value
    updateMinManaText()
  end
  ui.minFriendHp.onValueChange = function(scroll, value)
    storage[panelName].minFriendHp = value

    updateFriendHpText()
  end
  ui.maxFriendHp.onValueChange = function(scroll, value)
    storage[panelName].maxFriendHp = value
    updateFriendHpText()
  end
  ui.spellName:setText(storage[panelName].spellName)
  ui.minMana:setValue(storage[panelName].minMana)
  ui.minFriendHp:setValue(storage[panelName].minFriendHp)
  ui.maxFriendHp:setValue(storage[panelName].maxFriendHp)

  macro(200, function()
    if storage[panelName].enabled and storage[panelName].spellName:len() > 0 and manapercent() > storage[panelName].minMana then
      for _, spec in ipairs(getSpectators()) do
        if spec:isPlayer() and storage[panelName].minFriendHp >= spec:getHealthPercent() and spec:getHealthPercent() <= storage[panelName].maxFriendHp then
          if storage[panelName].partyAndGuildMembers and (spec:getShield() >= 3 or spec:getEmblem() == 1) then
              saySpell(storage[panelName].spellName .. ' "' .. spec:getName(), 100)
          end
          if table.contains(storage[panelName].sioList, spec:getName()) then
            saySpell(storage[panelName].spellName .. ' "' .. spec:getName(), 100)
          end
        end
      end
    end
  end)
end
friendHealer(batTab)
addSeparator("sep", batTab)

function autoBuffSpell(parent)
  local lastBuffSpell = 0
  macro(100, "Auto Buff spell", nil, function()
    if not hasPartyBuff() or now > lastBuffSpell + 90000 then
      if saySpell(storage.autoBuffText, 2000) then
        lastBuffSpell = now
      end
    end
  end, parent)
  addTextEdit("autoBuffText", storage.autoBuffText or "utito tempo san", function(widget, text)    
    storage.autoBuffText = text
  end, parent)
end
autoBuffSpell(batTab)

addSeparator("sep", batTab)

local mineableIds = {5636,5635,5632,3635,5732,7989,7996,8169,7994,8136,7994,5753,3661,3608,3662,8135,7995,7989,8168,5747,354,355,4475,4472,4473,4476,4470,4471,4474,4485,4473,4478,4477,3339,5623,5708,5622,4469}
local mineThing = nil
macro(10, "Mine", function()
  if mineThing == nil then
    tiles = g_map.getTiles(posz())
    randomTile = tiles[math.random(1,#tiles)]
    if not canStandBy(randomTile:getPosition()) or getDistanceBetween(pos(), randomTile:getPosition()) > 4 then
      return
    end
    for _, thing in ipairs(randomTile:getThings()) do
      for _,mineableId in ipairs(mineableIds) do
        if thing:getId() == mineableId then
          mineThing = thing
          return
        end
      end
    end
  else
    useWith(3456, mineThing)
  end
end)


function autoFollow(parent)
  macro(100, "Auto follow", nil, function()
    local target = g_game.getAttackingCreature()
    if target == nil and storage.autoFollowName ~= nil and storage.autoFollowName:len() > 0 and g_game.getFollowingCreature() == nil then
      for _, spec in ipairs(getSpectators()) do
        if spec:getName() == storage.autoFollowName then
          g_game.follow(spec)
        end
      end
    end
  end, parent)
  addTextEdit("autoFollowName", storage.autoFollowName, function(widget, text)    
    storage.autoFollowName = text
  end, parent)
end
autoFollow()


function runePartyAndGuildMembers(parent)
  if not parent then
    parent = panel
  end
  
  local panelName = "runePartyAndGuildMembers"
  local ui = setupUI([[
Panel
  height: 65
      
  BotItem
    id: item
    anchors.left: parent.left
    anchors.top: parent.top
    
  BotSwitch
    id: title
    anchors.left: prev.right
    anchors.right: parent.right
    anchors.verticalCenter: prev.verticalCenter
    text-align: center
    margin-left: 2
    margin-top: 0

  BotLabel
    id: friendHp
    anchors.left: parent.left
    anchors.right: parent.right
    anchors.top: item.bottom
    text-align: center

  HorizontalScrollBar
    id: minFriendHp
    anchors.left: parent.left
    anchors.right: parent.horizontalCenter
    anchors.top: friendHp.bottom
    margin-right: 2
    margin-top: 2
    minimum: 1
    maximum: 100
    step: 1
    
  HorizontalScrollBar
    id: maxFriendHp
    anchors.left: parent.horizontalCenter
    anchors.right: parent.right
    anchors.top: prev.top
    margin-left: 2
    minimum: 1
    maximum: 100
    step: 1    
  ]], parent)
  ui:setId(panelName)
  
  ui.title:setText("Rune party/guild")
  
  if not storage[panelName] then
    storage[panelName] = {
      minFriendHp = 40,
      maxFriendHp = 90,
      item = 3160
    }
  end
  
  ui.title:setOn(storage[panelName].enabled)
  ui.title.onClick = function(widget)
    storage[panelName].enabled = not storage[panelName].enabled
    widget:setOn(storage[panelName].enabled)
  end
  
  ui.item.onItemChange = function(widget)
    storage[panelName].item = widget:getItemId()
  end
  ui.item:setItemId(storage[panelName].item)

  local updateFriendHpText = function()
    ui.friendHp:setText("" .. storage[panelName].minFriendHp .. "% <= hp >= " .. storage[panelName].maxFriendHp .. "%")  
  end
  ui.minFriendHp.onValueChange = function(scroll, value)
    storage[panelName].minFriendHp = value
    updateFriendHpText()
  end
  ui.maxFriendHp.onValueChange = function(scroll, value)
    storage[panelName].maxFriendHp = value
    updateFriendHpText()
  end
  ui.minFriendHp:setValue(storage[panelName].minFriendHp)
  ui.maxFriendHp:setValue(storage[panelName].maxFriendHp)

  macro(200, function()
    if not storage[panelName].enabled then
      return
    end
    for _, spec in ipairs(getSpectators()) do
      if spec:isPlayer() and (spec:getShield() >= 3 or spec:getEmblem() == 1) then
        if storage[panelName].minFriendHp >= spec:getHealthPercent() and spec:getHealthPercent() <= storage[panelName].maxFriendHp then
          useWith(storage[panelName].item, spec)
        end
      end
    end
  end)
end
runePartyAndGuildMembers(batTab)
addSeparator("sep", batTab)